
public class BoardCell {

	private int row, column;
}
